package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.domain.IsNotRainyDTO;
import util.DBUtil;

public class IsNotRainyEndDAO {
	public static ArrayList<IsNotRainyDTO> getAll(String dong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<IsNotRainyDTO> data = null;
		String sql = "select oname, fname, tfname, cname, pname, rname, sname"
				+ " from Olle, Festival, Tf, Camping, Park, Restaurant, Sleep"
				+ " where oend = ? and oend = fdong and oend = tfdong and oend = cdong and oend = pdong and oend = rdong and oend = sdong";
		try {
			data = new ArrayList<IsNotRainyDTO>();
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dong);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				data.add(new IsNotRainyDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
}