package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.domain.FestivalDTO;
import util.DBUtil;

public class FestivalDAO {
	public static ArrayList<FestivalDTO> getAll() throws SQLException {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<FestivalDTO> datas = null;
		try {
			con = DBUtil.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from Festival");

			datas = new ArrayList<FestivalDTO>();
			while (rs.next()) {
				datas.add(new FestivalDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4),
						rs.getString(5), rs.getString(6), rs.getString(7)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, stmt, rs);
		}
		return datas;
	}

	// Ư�� ���� �˻�
	public static FestivalDTO getOne(String fdong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		FestivalDTO data = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from Festival where fdong = ?");
			pstmt.setString(1, fdong);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				data = new FestivalDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5),
						rs.getString(6), rs.getString(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}

	public static ArrayList<String> getDistinctname(String dong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<String> data = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select distinct(fname) from Festival where fdong = ?");
			pstmt.setString(1, dong);
			rs = pstmt.executeQuery();
			data = new ArrayList<String>();
			while (rs.next()) {
				data.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}

	public static FestivalDTO getDetail(String name) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		FestivalDTO data = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from Festival where fname = ?");
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				data = new FestivalDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5),
						rs.getString(6), rs.getString(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
}