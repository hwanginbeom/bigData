package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.domain.ParkDTO;
import util.DBUtil;

public class ParkDAO {
	public static ArrayList<ParkDTO> getAll() throws SQLException {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<ParkDTO> datas=null;
		try {
			con = DBUtil.getConnection();
			stmt = con.createStatement();
			rs =stmt.executeQuery("select * from Park");
			
			datas = new ArrayList<ParkDTO>();
			while(rs.next()) {
				datas.add(new ParkDTO(rs.getString(1), rs.getString(2), rs.getString(3)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; //catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, stmt, rs);
		}
		return datas;
	}
	// Ư�� ���� �˻�
	public static ParkDTO getOne(String pdong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		ParkDTO data = null; 
//		String sql ="select * from dept where deptno = ?";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from park where pdong = ?");
			pstmt.setString(1, pdong);
			rs =pstmt.executeQuery();
			while(rs.next()) {
			data = new ParkDTO(rs.getString(1), rs.getString(2), rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; //catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
	public static ParkDTO getDetail(String name) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		ParkDTO data = null; 
//		String sql ="select * from dept where deptno = ?";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from park where pname = ?");
			pstmt.setString(1, name);
			rs =pstmt.executeQuery();
			while(rs.next()) {
			data = new ParkDTO(rs.getString(1), rs.getString(2), rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; //catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
	public static ArrayList<String> getDistinctname(String dong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		ArrayList<String> data = null; 
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select distinct(pname) from Park where pdong = ?");
			pstmt.setString(1, dong);
			rs =pstmt.executeQuery();
			data = new ArrayList<String>();
			while(rs.next()) {
			data.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; //catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
}
