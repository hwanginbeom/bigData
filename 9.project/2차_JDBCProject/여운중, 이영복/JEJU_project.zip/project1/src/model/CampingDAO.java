package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.domain.CampingDTO;
import util.DBUtil;

public class CampingDAO {

	// ��� ���� �˻�
	public static ArrayList<CampingDTO> getAll() throws SQLException {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<CampingDTO> datas = null;
		try {
			con = DBUtil.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from Camping");

			datas = new ArrayList<CampingDTO>();
			while (rs.next()) {
				datas.add(new CampingDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4),
						rs.getString(5)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, stmt, rs);
		}
		return datas;
	}

	// Ư�� ���� �˻�
	public static CampingDTO getOne(String cdong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CampingDTO data = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from Camping where cdong = ?");
			pstmt.setString(1, cdong);
			rs = pstmt.executeQuery();
			while (rs.next()) {

				data = new CampingDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getLong(4), rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
	public static CampingDTO getDetail(String name) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CampingDTO data = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from Camping where cname = ?");
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {

				data = new CampingDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getLong(4), rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
	public static ArrayList<String> getDistinctname(String dong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<String> data = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select distinct(cname) from Camping where cdong = ?");
			pstmt.setString(1, dong);
			rs = pstmt.executeQuery();
			data = new ArrayList<String>();
			while (rs.next()) {
				data.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
}
