package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.domain.RentcarDTO;
import util.DBUtil;

public class RentcarDAO {
	public static ArrayList<RentcarDTO> getAll() throws SQLException {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<RentcarDTO> datas=null;
		try {
			con = DBUtil.getConnection();
			stmt = con.createStatement();
			rs =stmt.executeQuery("select * from rc");
			
			datas = new ArrayList<RentcarDTO>();
			while(rs.next()) {
				datas.add(new RentcarDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getString(6)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; //catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, stmt, rs);
		}
		return datas;
	}
	// Ư�� ���� �˻�
	public static RentcarDTO getOne(String rcdong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		RentcarDTO data = null; 
//		String sql ="select * from dept where deptno = ?";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from rc where rcdong = ?");
			pstmt.setString(1, rcdong);
			rs =pstmt.executeQuery();
			while(rs.next()) {
			data = new RentcarDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getString(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; //catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
}
