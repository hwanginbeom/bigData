package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.domain.TravelDTO;
import util.DBUtil;

public class TravelDAO {
	public static ArrayList<TravelDTO> RgetAll() throws SQLException {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<TravelDTO> datas = null;
		try {
			con = DBUtil.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from Travel");

			datas = new ArrayList<TravelDTO>();
			while (rs.next()) {
				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				System.out.println(rs.getInt(4));
				System.out.println(rs.getString(5));
				datas.add(new TravelDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4),
						rs.getString(5)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, stmt, rs);
		}
		return datas;
	}

	// Ư�� ���� �˻�
	public static TravelDTO getOne(String tdong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TravelDTO data = null;
		// String sql ="select * from dept where deptno = ?";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from travel where tdong = ?");
			pstmt.setString(1, tdong);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				data = new TravelDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
	// public static void main(String[] args) {
	// try {
	// RgetAll();
	// } catch (SQLException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// }
}