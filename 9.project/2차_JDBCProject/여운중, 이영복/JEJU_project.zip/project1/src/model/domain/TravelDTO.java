package model.domain;

public class TravelDTO {
   private String tname;
   private String tadmin;
   private String taddr;
   private long ttel;
   private String tdong;

   public TravelDTO() {
      super();
      // TODO Auto-generated constructor stub
   }

   public TravelDTO(String tname, String tadmin, String taddr, long ttel, String tdong) {
      super();
      this.tname = tname;
      this.tadmin = tadmin;
      this.taddr = taddr;
      this.ttel = ttel;
      this.tdong = tdong;
   }

   public String getTname() {
      return tname;
   }

   public void setTname(String tname) {
      this.tname = tname;
   }

   public String getTadmin() {
      return tadmin;
   }

   public void setTadmin(String tadmin) {
      this.tadmin = tadmin;
   }

   public String getTaddr() {
      return taddr;
   }

   public void setTaddr(String taddr) {
      this.taddr = taddr;
   }

   public long getTtel() {
      return ttel;
   }

   public void setTtel(long ttel) {
      this.ttel = ttel;
   }

   public String getTdong() {
      return tdong;
   }

   public void setTdong(String tdong) {
      this.tdong = tdong;
   }

   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("[�� �����ü �� =");
      builder.append(tname);
      builder.append(", ��ǥ�� =");
      builder.append(tadmin);
      builder.append(", �ּ� =");
      builder.append(taddr);
      builder.append(", ����ó =");
      builder.append(ttel);
      builder.append(", �����ü �� =");
      builder.append(tdong);
      builder.append("]");
      return builder.toString();
   }
}