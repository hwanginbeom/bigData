package model.domain;

public class ContactDTO {
   private String ctname;
   private int cttel;
   private String ctgen;
   private String ctdong;
   public ContactDTO() {
      super();
      // TODO Auto-generated constructor stub
   }
   public ContactDTO(String ctname, int cttel, String ctgen, String ctdong) {
      super();
      this.ctname = ctname;
      this.cttel = cttel;
      this.ctgen = ctgen;
      this.ctdong = ctdong;
   }
   public String getCtname() {
      return ctname;
   }
   public void setCtname(String ctname) {
      this.ctname = ctname;
   }
   public int getCttel() {
      return cttel;
   }
   public void setCttel(int cttel) {
      this.cttel = cttel;
   }
   public String getCtgen() {
      return ctgen;
   }
   public void setCtgen(String ctgen) {
      this.ctgen = ctgen;
   }
   public String getCtdong() {
      return ctdong;
   }
   public void setCtdong(String ctdong) {
      this.ctdong = ctdong;
   }
   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("[�� �̸� =");
      builder.append(ctname);
      builder.append(", ����ó =");
      builder.append(cttel);
      builder.append(", ���� =");
      builder.append(ctgen);
      builder.append(", ��� ��� ��ġ =");
      builder.append(ctdong);
      builder.append("]");
      return builder.toString();
   }
}