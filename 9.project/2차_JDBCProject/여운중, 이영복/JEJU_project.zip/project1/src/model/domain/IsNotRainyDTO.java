package model.domain;


public class IsNotRainyDTO {
   private String oname;
   private String fname;
   private String tfname;
   private String cname;
   private String pname;
   private String rname;
   private String sname;
   
   public IsNotRainyDTO() {
      super();
   }
   public IsNotRainyDTO(String oname, String fname, String tfname, String cname, String pname, String rname,
         String sname) {
      super();
      this.oname = oname;
      this.fname = fname;
      this.tfname = tfname;
      this.cname = cname;
      this.pname = pname;
      this.rname = rname;
      this.sname = sname;
   }
   public String getOname() {
      return oname;
   }
   public void setOname(String oname) {
      this.oname = oname;
   }
   public String getFname() {
      return fname;
   }
   public void setFname(String fname) {
      this.fname = fname;
   }
   public String getTfname() {
      return tfname;
   }
   public void setTfname(String tfname) {
      this.tfname = tfname;
   }
   public String getCname() {
      return cname;
   }
   public void setCname(String cname) {
      this.cname = cname;
   }
   public String getPname() {
      return pname;
   }
   public void setPname(String pname) {
      this.pname = pname;
   }
   public String getRname() {
      return rname;
   }
   public void setRname(String rname) {
      this.rname = rname;
   }
   public String getSname() {
      return sname;
   }
   public void setSname(String sname) {
      this.sname = sname;
   }
   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("[�� �÷��� �ڽ��� =");
      builder.append(oname);
      builder.append(", ���� �� =");
      builder.append(fname);
      builder.append(", ��ȭ���� �� =");
      builder.append(tfname);
      builder.append(", ķ���� �� =");
      builder.append(cname);
      builder.append(", ���ð��� �� =");
      builder.append(pname);
      builder.append(", �Ĵ� ��=");
      builder.append(rname);
      builder.append(", �ι� �� =");
      builder.append(sname);
      builder.append("]");
      return builder.toString();
   }
}