package model.domain;

public class SleepDTO {
   private String sname;
   private String swhere;
   private String sroom;
   private String sdong;

   public SleepDTO() {
      super();
      // TODO Auto-generated constructor stub
   }

   public SleepDTO(String sname, String swhere, String sroom, String sdong) {
      super();
      this.sname = sname;
      this.swhere = swhere;
      this.sroom = sroom;
      this.sdong = sdong;
   }

   public String getSname() {
      return sname;
   }

   public void setSname(String sname) {
      this.sname = sname;
   }

   public String getSwhere() {
      return swhere;
   }

   public void setSwhere(String swhere) {
      this.swhere = swhere;
   }

   public String getSroom() {
      return sroom;
   }

   public void setSroom(String sroom) {
      this.sroom = sroom;
   }

   public void setSdong(String sdong) {
      this.sdong = sdong;
   }

   public String getSdong() {
      return sdong;
   }

   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("[�� �ιڸ� =");
      builder.append(sname);
      builder.append(", �ι� ��ġ =");
      builder.append(swhere);
      builder.append(", ���� �� =");
      builder.append(sroom);
      builder.append(", �ι� �� =");
      builder.append(sdong);
      builder.append("]");
      return builder.toString();
   }
}