package model.domain;

public class RestaurantDTO {
   private String rname;
   private String rwhere;
   private int rtel;
   private String rcontent;
   private String rdong;

   public RestaurantDTO() {
      super();
      // TODO Auto-generated constructor stub
   }

   public RestaurantDTO(String rname, String rwhere, int rtel, String rcontent, String rdong) {
      super();
      this.rname = rname;
      this.rwhere = rwhere;
      this.rtel = rtel;
      this.rcontent = rcontent;
      this.rdong = rdong;
   }

   public String getRname() {
      return rname;
   }

   public void setRname(String rname) {
      this.rname = rname;
   }

   public String getRwhere() {
      return rwhere;
   }

   public void setRwhere(String rwhere) {
      this.rwhere = rwhere;
   }

   public int getRtel() {
      return rtel;
   }

   public void setRtel(int rtel) {
      this.rtel = rtel;
   }

   public String getRcontent() {
      return rcontent;
   }

   public void setRcontent(String rcontent) {
      this.rcontent = rcontent;
   }

   public String getRdong() {
      return rdong;
   }

   public void setRdong(String rdong) {
      this.rdong = rdong;
   }

   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("[�� �Ĵ�� =");
      builder.append(rname);
      builder.append(", �Ĵ� �ּ� =");
      builder.append(rwhere);
      builder.append(", �Ĵ� ����ó =");
      builder.append(rtel);
      builder.append(", �Ļ� ���� =");
      builder.append(rcontent);
      builder.append(", �Ĵ� �� =");
      builder.append(rdong);
      builder.append("]");
      return builder.toString();
   }
}