package model.domain;

public class OlleDTO {
      private String ocourse;
      private String oname;
      private String odistance;
      private String ostartend;
      private String ostart;
      private String oend;
      public OlleDTO() {
         super();
         // TODO Auto-generated constructor stub
      }
      public OlleDTO(String ocourse, String oname, String odistance, String ostartend, String ostart, String oend) {
         super();
         this.ocourse = ocourse;
         this.oname = oname;
         this.odistance = odistance;
         this.ostartend = ostartend;
         this.ostart = ostart;
         this.oend = oend;
      }
      public String getOcourse() {
         return ocourse;
      }
      public void setOcourse(String ocourse) {
         this.ocourse = ocourse;
      }
      public String getOname() {
         return oname;
      }
      public void setOname(String oname) {
         this.oname = oname;
      }
      public String getOdistance() {
         return odistance;
      }
      public void setOdistance(String odistance) {
         this.odistance = odistance;
      }
      public String getOstartend() {
         return ostartend;
      }
      public void setOstartend(String ostartend) {
         this.ostartend = ostartend;
      }
      public String getOstart() {
         return ostart;
      }
      public void setOstart(String ostart) {
         this.ostart = ostart;
      }
      public String getOend() {
         return oend;
      }
      public void setOend(String oend) {
         this.oend = oend;
      }
      @Override
      public String toString() {
         StringBuilder builder = new StringBuilder();
         builder.append("[�� �ڽ� ��=");
         builder.append(ocourse);
         builder.append(", �ڽ� �̸� =");
         builder.append(oname);
         builder.append(", �ڽ� �Ÿ� =");
         builder.append(odistance);
         builder.append(", ���� ~ ���� =");
         builder.append(ostartend);
         builder.append(", ���� ��ġ =");
         builder.append(ostart);
         builder.append(", ���� ��ġ =");
         builder.append(oend);
         builder.append("]");
         return builder.toString();
      }
      
   }