package model.domain;

public class ParkDTO {
      private String pname;
      private String paddr;
      private String pdong;
      public ParkDTO() {
         super();
         // TODO Auto-generated constructor stub
      }
      public ParkDTO(String pname, String paddr, String pdong) {
         super();
         this.pname = pname;
         this.paddr = paddr;
         this.pdong = pdong;
      }
      public String getPname() {
         return pname;
      }
      public void setPname(String pname) {
         this.pname = pname;
      }
      public String getPaddr() {
         return paddr;
      }
      public void setPaddr(String paddr) {
         this.paddr = paddr;
      }
      public String getPdong() {
         return pdong;
      }
      public void setPdong(String pdong) {
         this.pdong = pdong;
      }
      @Override
      public String toString() {
         StringBuilder builder = new StringBuilder();
         builder.append("[�� ���� �� =");
         builder.append(pname);
         builder.append(", ���� �ּ� =");
         builder.append(paddr);
         builder.append(", ���� �� =");
         builder.append(pdong);
         builder.append("]");
         return builder.toString();
      }
   }