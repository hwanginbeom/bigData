package model.domain;

//rc table�� travel table�� join
public class IsRainyDTO {
   private String rcname;
   private String tname;

   public IsRainyDTO() {
      super();
      // TODO Auto-generated constructor stub
   }

   public IsRainyDTO(String rcname, String tname) {
      super();
      this.rcname = rcname;
      this.tname = tname;
   }

   public String getRcname() {
      return rcname;
   }

   public void setRcname(String rcname) {
      this.rcname = rcname;
   }

   public String getTname() {
      return tname;
   }

   public void setTname(String tname) {
      this.tname = tname;
   }

   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("[�� ��Ʈ ī ��ü �� =");
      builder.append(rcname);
      builder.append(", ���� ��ü �� =");
      builder.append(tname);
      builder.append("]");
      return builder.toString();
   }

}