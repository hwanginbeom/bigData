package model.domain;

public class CampingDTO {
      private String cname;
      private String ccontent;
      private String caddr;
      private long ctel;
      private String cdong;
      public CampingDTO() {
         super();
         // TODO Auto-generated constructor stub
      }
      public CampingDTO(String cname, String ccontent, String caddr, long ctel, String cdong) {
         super();
         this.cname = cname;
         this.ccontent = ccontent;
         this.caddr = caddr;
         this.ctel = ctel;
         this.cdong = cdong;
      }
      public String getCname() {
         return cname;
      }
      public void setCname(String cname) {
         this.cname = cname;
      }
      public String getCcontent() {
         return ccontent;
      }
      public void setCcontent(String ccontent) {
         this.ccontent = ccontent;
      }
      public String getCaddr() {
         return caddr;
      }
      public void setCaddr(String caddr) {
         this.caddr = caddr;
      }
      public long getCtel() {
         return ctel;
      }
      public void setCtel(long ctel) {
         this.ctel = ctel;
      }
      public String getCdong() {
         return cdong;
      }
      public void setCdong(String cdong) {
         this.cdong = cdong;
      }
      @Override
      public String toString() {
         StringBuilder builder = new StringBuilder();
         builder.append("[�� ķ����� = ");
         builder.append(cname);
         builder.append(", ķ���� ���� = ");
         builder.append(ccontent);
         builder.append(", ķ���� �ּ�=");
         builder.append(caddr);
         builder.append(", ķ���� ��ȣ=");
         builder.append(ctel);
         builder.append(", ķ���� ��ġ=");
         builder.append(cdong);
         builder.append("]");
         return builder.toString();
      }
   }