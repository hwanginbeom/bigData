package model.domain;

public class TfDTO {
   private String tfname;
   private String tfwhere;
   private int tfstartdate;
   private String tfcontent;
   private int tftel;
   private String tfaddr;
   private String tfdong;

   public TfDTO() {
      super();
      // TODO Auto-generated constructor stub
   }

   public TfDTO(String tfname, String tfwhere, int tfstartdate, String tfcontent, int tftel, String tfaddr,
         String tfdong) {
      super();
      this.tfname = tfname;
      this.tfwhere = tfwhere;
      this.tfstartdate = tfstartdate;
      this.tfcontent = tfcontent;
      this.tftel = tftel;
      this.tfaddr = tfaddr;
      this.tfdong = tfdong;
   }

   public String getTfname() {
      return tfname;
   }

   public void setTfname(String tfname) {
      this.tfname = tfname;
   }

   public String getTfwhere() {
      return tfwhere;
   }

   public void setTfwhere(String tfwhere) {
      this.tfwhere = tfwhere;
   }

   public int getTfstartdate() {
      return tfstartdate;
   }

   public void setTfstartdate(int tfstartdate) {
      this.tfstartdate = tfstartdate;
   }

   public String getTfcontent() {
      return tfcontent;
   }

   public void setTfcontent(String tfcontent) {
      this.tfcontent = tfcontent;
   }

   public int getTftel() {
      return tftel;
   }

   public void setTftel(int tftel) {
      this.tftel = tftel;
   }

   public String getTfaddr() {
      return tfaddr;
   }

   public void setTfaddr(String tfaddr) {
      this.tfaddr = tfaddr;
   }

   public String getTfdong() {
      return tfdong;
   }

   public void setTfdong(String tfdong) {
      this.tfdong = tfdong;
   }

   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("[�� ��ȭ ���� �� =");
      builder.append(tfname);
      builder.append(", ��ȭ ���� ��ġ =");
      builder.append(tfwhere);
      builder.append(", ������ =");
      builder.append(tfstartdate);
      builder.append(", ���� ���� =");
      builder.append(tfcontent);
      builder.append(", ����ó =");
      builder.append(tftel);
      builder.append(", �ּ� =");
      builder.append(tfaddr);
      builder.append(", ��ȭ���� �� =");
      builder.append(tfdong);
      builder.append("]");
      return builder.toString();
   }
}