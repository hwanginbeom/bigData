package model.domain;

public class RentcarDTO {
   private String rcname;
   private String rcadmin;
   private String rccar;
   private String rcwhere;
   private String rdong;

   public RentcarDTO() {
      super();
      // TODO Auto-generated constructor stub
   }

   public RentcarDTO(String rcname, String rcadmin, String rccar, String rcwhere, int rctel, String rdong) {
      super();
      this.rcname = rcname;
      this.rcadmin = rcadmin;
      this.rccar = rccar;
      this.rcwhere = rcwhere;
      this.rctel = rctel;
      this.rdong = rdong;
   }

   private int rctel;

   public String getRcname() {
      return rcname;
   }

   public void setRcname(String rcname) {
      this.rcname = rcname;
   }

   public String getRcadmin() {
      return rcadmin;
   }

   public void setRcadmin(String rcadmin) {
      this.rcadmin = rcadmin;
   }

   public String getRccar() {
      return rccar;
   }

   public void setRccar(String rccar) {
      this.rccar = rccar;
   }

   public String getRcwhere() {
      return rcwhere;
   }

   public void setRcwhere(String rcwhere) {
      this.rcwhere = rcwhere;
   }

   public int getRctel() {
      return rctel;
   }

   public void setRctel(int rctel) {
      this.rctel = rctel;
   }

   public String getRdong() {
      return rdong;
   }

   public void setRdong(String rdong) {
      this.rdong = rdong;
   }

   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("[�� ��Ʈ ī ��ü ��=");
      builder.append(rcname);
      builder.append(", ��ǥ�� =");
      builder.append(rcadmin);
      builder.append(", �¿��� ���� �� =");
      builder.append(rccar);
      builder.append(", �ּ� =");
      builder.append(rcwhere);
      builder.append(", ����ó =");
      builder.append(rctel);
      builder.append(", ��Ʈī �� =");
      builder.append(rdong);
      builder.append("]");
      return builder.toString();
   }
}