package model.domain;

public class FestivalDTO {
   private String fname;
   private String fwhere;
   private String fcontent;
   private int ftel;
   private String fweb;
   private String faddr;
   private String fdong;

   public FestivalDTO() {
   }

   public FestivalDTO(String fname, String fwhere, String fcontent, int ftel, String fweb,
         String faddr, String fdong) {
      super();
      this.fname = fname;
      this.fwhere = fwhere;
      this.fcontent = fcontent;
      this.ftel = ftel;
      this.fweb = fweb;
      this.faddr = faddr;
      this.fdong = fdong;
   }

   public String getFname() {
      return fname;
   }

   public void setFname(String fname) {
      this.fname = fname;
   }

   public String getFwhere() {
      return fwhere;
   }

   public void setFwhere(String fwhere) {
      this.fwhere = fwhere;
   }

   public String getFcontent() {
      return fcontent;
   }

   public void setFcontent(String fcontent) {
      this.fcontent = fcontent;
   }

   public int getFtel() {
      return ftel;
   }

   public void setFtel(int ftel) {
      this.ftel = ftel;
   }

   public String getFweb() {
      return fweb;
   }

   public void setFweb(String fweb) {
      this.fweb = fweb;
   }

   public String getFaddr() {
      return faddr;
   }
   public void setFaddr(String faddr) {
      this.faddr = faddr;
   }
   
   public void setFdong(String fdong) {
      this.fdong = fdong;
   }
   public String getFdong() {
      return fdong;
   }



   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("[�� ������=");
      builder.append(fname);
      builder.append(", ���� ��ġ=");
      builder.append(fwhere);
      builder.append(", ���� ����=");
      builder.append(fcontent);
      builder.append(", ����ó =");
      builder.append(ftel);
      builder.append(", �����ּ� =");
      builder.append(fweb);
      builder.append(", �ּ� =");
      builder.append(faddr);
      builder.append(", ���� ��ġ �� =");
      builder.append(fdong);
      builder.append("]");
      return builder.toString();
   }

}