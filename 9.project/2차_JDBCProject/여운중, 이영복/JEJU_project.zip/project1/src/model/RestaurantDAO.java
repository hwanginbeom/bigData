package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.domain.RestaurantDTO;
import util.DBUtil;

public class RestaurantDAO {
	public static ArrayList<RestaurantDTO> getAll() throws SQLException {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<RestaurantDTO> datas = null;
		try {
			con = DBUtil.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from restaurant");

			datas = new ArrayList<RestaurantDTO>();
			while (rs.next()) {
				datas.add(new RestaurantDTO(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4),
						rs.getString(5)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, stmt, rs);
		}
		return datas;
	}

	// Ư�� ���� �˻�
	public static RestaurantDTO getOne(String rdong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		RestaurantDTO data = null;
		// String sql ="select * from dept where deptno = ?";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from restaurant where rdong = ?");
			pstmt.setString(1, rdong);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				data = new RestaurantDTO(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4),
						rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
	public static RestaurantDTO getDetail(String name) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		RestaurantDTO data = null;
		// String sql ="select * from dept where deptno = ?";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from restaurant where rname = ?");
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				data = new RestaurantDTO(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4),
						rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
	public static ArrayList<String> getDistinctname(String dong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<String> data = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select distinct(rname) from Restaurant where rdong = ?");
			pstmt.setString(1, dong);
			rs = pstmt.executeQuery();
			data = new ArrayList<String>();
			while (rs.next()) {
				data.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}
}
