package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.domain.IsRainyDTO;
import util.DBUtil;

public class IsRainyDAO {

   public static IsRainyDTO getOne(String dong) throws SQLException{
      Connection con = null;
      PreparedStatement pstmt =null;
      ResultSet rs = null;
      IsRainyDTO data = null; 
      String sql ="select Tname,Rcname from Travel, Rc where Tdong = rcdong and tdong = ?";
      try {
         data = new IsRainyDTO();
         con = DBUtil.getConnection();
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1, dong);
         rs =pstmt.executeQuery();
         while(rs.next()) {
            data = new IsRainyDTO(rs.getString(1), rs.getString(2));
         }
      } catch (SQLException e) {
         e.printStackTrace();
         throw e; //catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
      } finally {
         DBUtil.close(con, pstmt, rs);
      }
      return data;

   }
}