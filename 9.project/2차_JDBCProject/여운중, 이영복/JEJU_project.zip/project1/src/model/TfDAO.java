package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.domain.TfDTO;
import util.DBUtil;

public class TfDAO {
	public static ArrayList<TfDTO> getAll() throws SQLException {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<TfDTO> datas = null;
		try {
			con = DBUtil.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from Tf");

			datas = new ArrayList<TfDTO>();
			while (rs.next()) {
				datas.add(new TfDTO(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getInt(5),
						rs.getString(6), rs.getString(7)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, stmt, rs);
		}
		return datas;
	}

	// Ư�� ���� �˻�
	public static TfDTO getOne(String deptno) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TfDTO data = null;
		// String sql ="select * from dept where deptno = ?";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from Tf where tfdong = ?");
			pstmt.setString(1, deptno);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				data = new TfDTO(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getInt(5),
						rs.getString(6), rs.getString(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}

	public static TfDTO getDetail(String name) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TfDTO data = null;
		// String sql ="select * from dept where deptno = ?";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from Tf where tfname = ?");
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				data = new TfDTO(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getInt(5),
						rs.getString(6), rs.getString(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}

	public static ArrayList<String> getDistinctname(String dong) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<String> data = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select distinct(Tfname) from Tf where tfdong = ?");
			pstmt.setString(1, dong);
			rs = pstmt.executeQuery();
			data = new ArrayList<String>();
			while (rs.next()) {
				data.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // catch������ throw �ؾ߸� end user���� ��Ȳ ���� ����
		} finally {
			DBUtil.close(con, pstmt, rs);
		}
		return data;
	}

}