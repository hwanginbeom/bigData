package view;

import java.util.ArrayList;
import java.util.Scanner;

import model.domain.CampingDTO;
import model.domain.ContactDTO;
import model.domain.FestivalDTO;
import model.domain.IsNotRainyDTO;
import model.domain.IsRainyDTO;
import model.domain.OlleDTO;
import model.domain.ParkDTO;
import model.domain.RentcarDTO;
import model.domain.RestaurantDTO;
import model.domain.SleepDTO;
import model.domain.TfDTO;
import model.domain.TravelDTO;

public class EndView {
	public static void printNotRainy(ArrayList<IsNotRainyDTO> datas) {
		System.out.println(datas);
	}

	public static void errorMsg(String msg) {
		System.out.println("������ ���� : " + msg);
	}

	public static void succMsg(String msg) {
		System.out.println("���� ���� : " + msg);
	}

	public static void printOne(Object datas) {
		if (datas instanceof CampingDTO) {
			System.out.println((CampingDTO) datas);
		} else if (datas instanceof FestivalDTO) {
			System.out.println((FestivalDTO) datas);
		} else if (datas instanceof IsNotRainyDTO) {
			System.out.println((IsNotRainyDTO) datas);
		} else if (datas instanceof IsRainyDTO) {
			System.out.println((IsRainyDTO) datas);
		} else if (datas instanceof OlleDTO) {
			System.out.println((OlleDTO) datas);
		} else if (datas instanceof ParkDTO) {
			System.out.println((ParkDTO) datas);
		} else if (datas instanceof RentcarDTO) {
			System.out.println((RentcarDTO) datas);
		} else if (datas instanceof RestaurantDTO) {
			System.out.println((RestaurantDTO) datas);
		} else if (datas instanceof SleepDTO) {
			System.out.println((SleepDTO) datas);
		} else if (datas instanceof TfDTO) {
			System.out.println((TfDTO) datas);
		} else if (datas instanceof TravelDTO) {
			System.out.println((TravelDTO) datas);
		}
	}

	public static String printDistinctName(ArrayList<String> datas) {
		int a = 0;
		int size = datas.size();
		for (int i = 0; i < size; i++) {
			System.out.println(i + 1 + " : " + datas.get(i));
		}
		System.out.println("�� ������ ��� ��ȣ�� �����ϼ���");
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();

		return datas.get(a-1);
	}

	public static void printAll(ArrayList<ContactDTO> datas) {
		for (ContactDTO dto : datas) {
			System.out.println(dto.toString());
		}
	}

}
