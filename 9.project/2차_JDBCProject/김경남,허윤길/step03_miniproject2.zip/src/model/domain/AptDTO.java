package model.domain;

public class AptDTO {
	private String narea;
	private String roomsize;
	private int year;
	private int month;
	private String aptprice;
	
	public AptDTO() {
		super();
	}

	public AptDTO(String narea, String roomsize, int year, int month, String aptprice) {
		super();
		this.narea = narea;
		this.roomsize = roomsize;
		this.year = year;
		this.month = month;
		this.aptprice = aptprice;
	}
	
	public AptDTO(String narea, String roomsize, int year, int month) {
		super();
		this.narea = narea;
		this.roomsize = roomsize;
		this.year = year;
		this.month = month;
	}

	public String getNarea() {
		return narea;
	}

	public void setNarea(String narea) {
		this.narea = narea;
	}

	public String getRoomsize() {
		return roomsize;
	}

	public void setRoomsize(String roomsize) {
		this.roomsize = roomsize;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getAptprice() {
		return aptprice;
	}

	public void setAptprice(String aptprice) {
		this.aptprice = aptprice;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AptDTO [narea=");
		builder.append(narea);
		builder.append(", roomsize=");
		builder.append(roomsize);
		builder.append(", year=");
		builder.append(year);
		builder.append(", month=");
		builder.append(month);
		builder.append(", aptprice=");
		builder.append(aptprice);
		builder.append("]");
		return builder.toString();
	}
	
}
	