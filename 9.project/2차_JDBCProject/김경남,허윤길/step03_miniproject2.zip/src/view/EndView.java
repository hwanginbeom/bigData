package view;

import java.util.ArrayList;

import model.domain.AptDTO;

public class EndView {
   public static void printAll(ArrayList<AptDTO> datas) {

      for(AptDTO dto : datas) { 
         System.out.println(dto);
      }
   }
   public static void printOne(int datas) {
      System.out.println(datas);
   }
   
   public static void printOne1(int datas1) {
	      System.out.println(datas1);
	   }

   public static void succMsg(String string) {
      System.out.println(string);
   }

   public static void errorMsg(String string) {
      System.out.println(string);      
   }


}