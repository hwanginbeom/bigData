package model.domain;

public class ChickenDTO {
	String shop_name;
	String shop_address;
	String main_district;
	String small_district;
	int shop_size;
	String telephone;
	int directionX;
	int directionY;
	public ChickenDTO() {
		super();
	}
	public ChickenDTO(String shop_name, String shop_address, String main_district, String small_district, int shop_size,
			String telephone, int directionX, int directionY) {
		super();
		this.shop_name = shop_name;
		this.shop_address = shop_address;
		this.main_district = main_district;
		this.small_district = small_district;
		this.shop_size = shop_size;
		this.telephone = telephone;
		this.directionX = directionX;
		this.directionY = directionY;
	}
	public String getShop_name() {
		return shop_name;
	}
	public void setShop_name(String shop_name) {
		this.shop_name = shop_name;
	}
	public String getShop_address() {
		return shop_address;
	}
	public void setShop_address(String shop_address) {
		this.shop_address = shop_address;
	}
	public String getMain_district() {
		return main_district;
	}
	public void setMain_district(String main_district) {
		this.main_district = main_district;
	}
	public String getSmall_district() {
		return small_district;
	}
	public void setSmall_district(String small_district) {
		this.small_district = small_district;
	}
	public int getShop_size() {
		return shop_size;
	}
	public void setShop_size(int shop_size) {
		this.shop_size = shop_size;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public int getDirectionX() {
		return directionX;
	}
	public void setDirectionX(int directionX) {
		this.directionX = directionX;
	}
	public int getDirectionY() {
		return directionY;
	}
	public void setDirectionY(int directionY) {
		this.directionY = directionY;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ChickenDTO [shop_name=");
		builder.append(shop_name);
		builder.append(", shop_address=");
		builder.append(shop_address);
		builder.append(", main_district=");
		builder.append(main_district);
		builder.append(", small_district=");
		builder.append(small_district);
		builder.append(", shop_size=");
		builder.append(shop_size);
		builder.append(", telephone=");
		builder.append(telephone);
		builder.append(", directionX=");
		builder.append(directionX);
		builder.append(", directionY=");
		builder.append(directionY);
		builder.append("]");
		return builder.toString();
	}
	
	
	
}


