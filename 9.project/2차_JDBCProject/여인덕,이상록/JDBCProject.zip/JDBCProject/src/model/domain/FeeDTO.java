package model.domain;

public class FeeDTO {
	String location;
	String main_district;
	int square_meter_fee;
	
	public FeeDTO() {
		super();
	}
	public FeeDTO(String location, String main_district, int square_meter_fee) {
		super();
		this.location = location;
		this.main_district = main_district;
		this.square_meter_fee = square_meter_fee;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getMain_district() {
		return main_district;
	}
	public void setMain_district(String main_district) {
		this.main_district = main_district;
	}
	public int getSquare_meter_fee() {
		return square_meter_fee;
	}
	public void setSquare_meter_fee(int square_meter_fee) {
		this.square_meter_fee = square_meter_fee;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FeeDTO [location=");
		builder.append(location);
		builder.append(", main_district=");
		builder.append(main_district);
		builder.append(", square_meter_fee=");
		builder.append(square_meter_fee);
		builder.append("]");
		return builder.toString();
	}
	
}
