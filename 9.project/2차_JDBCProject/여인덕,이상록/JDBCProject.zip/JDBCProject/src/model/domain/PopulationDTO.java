package model.domain;

public class PopulationDTO {
	String date;
	int time;
	String main_district;
	String small_district;
	int total_population;
	int man_10s;
	int man_20s;
	int man_30s;
	int man_40s;
	int man_50s;
	int man_60s;
	int man_70s;
	int woman_10s;
	int woman_20s;
	int woman_30s;
	int woman_40s;
	int woman_50s;
	int woman_60s;
	int woman_70s;
	
	public PopulationDTO() {
		super();
	}

	public PopulationDTO(String date, int time, String main_district, String small_district, int total_population,
			int man_10s, int man_20s, int man_30s, int man_40s, int man_50s, int man_60s, int man_70s, int woman_10s,
			int woman_20s, int woman_30s, int woman_40s, int woman_50s, int woman_60s, int woman_70s) {
		super();
		this.date = date;
		this.time = time;
		this.main_district = main_district;
		this.small_district = small_district;
		this.total_population = total_population;
		this.man_10s = man_10s;
		this.man_20s = man_20s;
		this.man_30s = man_30s;
		this.man_40s = man_40s;
		this.man_50s = man_50s;
		this.man_60s = man_60s;
		this.man_70s = man_70s;
		this.woman_10s = woman_10s;
		this.woman_20s = woman_20s;
		this.woman_30s = woman_30s;
		this.woman_40s = woman_40s;
		this.woman_50s = woman_50s;
		this.woman_60s = woman_60s;
		this.woman_70s = woman_70s;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public String getMain_district() {
		return main_district;
	}

	public void setMain_district(String main_district) {
		this.main_district = main_district;
	}

	public String getSmall_district() {
		return small_district;
	}

	public void setSmall_district(String small_district) {
		this.small_district = small_district;
	}

	public int getTotal_population() {
		return total_population;
	}

	public void setTotal_population(int total_population) {
		this.total_population = total_population;
	}

	public int getMan_10s() {
		return man_10s;
	}

	public void setMan_10s(int man_10s) {
		this.man_10s = man_10s;
	}

	public int getMan_20s() {
		return man_20s;
	}

	public void setMan_20s(int man_20s) {
		this.man_20s = man_20s;
	}

	public int getMan_30s() {
		return man_30s;
	}

	public void setMan_30s(int man_30s) {
		this.man_30s = man_30s;
	}

	public int getMan_40s() {
		return man_40s;
	}

	public void setMan_40s(int man_40s) {
		this.man_40s = man_40s;
	}

	public int getMan_50s() {
		return man_50s;
	}

	public void setMan_50s(int man_50s) {
		this.man_50s = man_50s;
	}

	public int getMan_60s() {
		return man_60s;
	}

	public void setMan_60s(int man_60s) {
		this.man_60s = man_60s;
	}

	public int getMan_70s() {
		return man_70s;
	}

	public void setMan_70s(int man_70s) {
		this.man_70s = man_70s;
	}

	public int getWoman_10s() {
		return woman_10s;
	}

	public void setWoman_10s(int woman_10s) {
		this.woman_10s = woman_10s;
	}

	public int getWoman_20s() {
		return woman_20s;
	}

	public void setWoman_20s(int woman_20s) {
		this.woman_20s = woman_20s;
	}

	public int getWoman_30s() {
		return woman_30s;
	}

	public void setWoman_30s(int woman_30s) {
		this.woman_30s = woman_30s;
	}

	public int getWoman_40s() {
		return woman_40s;
	}

	public void setWoman_40s(int woman_40s) {
		this.woman_40s = woman_40s;
	}

	public int getWoman_50s() {
		return woman_50s;
	}

	public void setWoman_50s(int woman_50s) {
		this.woman_50s = woman_50s;
	}

	public int getWoman_60s() {
		return woman_60s;
	}

	public void setWoman_60s(int woman_60s) {
		this.woman_60s = woman_60s;
	}

	public int getWoman_70s() {
		return woman_70s;
	}

	public void setWoman_70s(int woman_70s) {
		this.woman_70s = woman_70s;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PopulationDTO [date=");
		builder.append(date);
		builder.append(", time=");
		builder.append(time);
		builder.append(", main_district=");
		builder.append(main_district);
		builder.append(", small_district=");
		builder.append(small_district);
		builder.append(", total_population=");
		builder.append(total_population);
		builder.append(", man_10s=");
		builder.append(man_10s);
		builder.append(", man_20s=");
		builder.append(man_20s);
		builder.append(", man_30s=");
		builder.append(man_30s);
		builder.append(", man_40s=");
		builder.append(man_40s);
		builder.append(", man_50s=");
		builder.append(man_50s);
		builder.append(", man_60s=");
		builder.append(man_60s);
		builder.append(", man_70s=");
		builder.append(man_70s);
		builder.append(", woman_10s=");
		builder.append(woman_10s);
		builder.append(", woman_20s=");
		builder.append(woman_20s);
		builder.append(", woman_30s=");
		builder.append(woman_30s);
		builder.append(", woman_40s=");
		builder.append(woman_40s);
		builder.append(", woman_50s=");
		builder.append(woman_50s);
		builder.append(", woman_60s=");
		builder.append(woman_60s);
		builder.append(", woman_70s=");
		builder.append(woman_70s);
		builder.append("]");
		return builder.toString();
	}
	
	
}
