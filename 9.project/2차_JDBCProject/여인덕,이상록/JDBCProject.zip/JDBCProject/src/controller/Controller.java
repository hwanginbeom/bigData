package controller;

import java.io.IOException;
import java.sql.SQLException;

import model.JDBC_DAO;
import model.domain.ChickenDTO;
import view.EndView;

public class Controller {
	
	private static Controller instance= new Controller();
	private Controller() {
		
	}
	public static Controller getInstance() {
		return instance;
	}
	public void insert(ChickenDTO newChicken) throws SQLException {
		 try {
			if(JDBC_DAO.insert(newChicken)) {
				EndView.succMsg("���� ����!!!!!");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			EndView.errorMsg("���� �����Դϴ�!!");
		}
	
}
	public void update(String oldname, String newname) throws SQLException {
		 try {
			if(JDBC_DAO.update(oldname,newname)) {
				EndView.succMsg("���� ����!!!!!");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			EndView.errorMsg("���� �����Դϴ�!!");
		}
	
}
	public void delete(int newsize) throws SQLException {
		 try {
			if(JDBC_DAO.delete(newsize)) {
				EndView.succMsg("���� ����!!!!!");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			EndView.errorMsg("���� �����Դϴ�!!");
		}
	
}
	
}
	public void read2(int population) throws SQLException {
		 try {
			if(JDBC_DAO.read2(population)!=0) {
				System.out.println(JDBC_DAO.read2(population));
				EndView.succMsg("������ Ž�� ����!");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			EndView.errorMsg("������ Ž�� ����!");
		}
}
	public void read1(String small_district) throws SQLException {
	       try {
	         if(JDBC_DAO.read1(small_district)!=0) {
	            System.out.println(JDBC_DAO.read1(small_district));
	            
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	         EndView.errorMsg("������ Ž�� ����!");
	      }
	}
	
}